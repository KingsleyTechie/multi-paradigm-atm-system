ATM System - Multi-Paradigm Implementation
==========================================

This project contains a Python implementation of a simplified ATM system. The code demonstrates Object-Oriented, Procedural, and Functional programming paradigms within a single application.

Project File
------------
The project consists of a single file:
- `atm.py` : The main Python script containing the complete ATM system.

Prerequisites
-------------
To run this program, you need to have Python installed on your computer.

- **Python 3.6 or higher** is recommended.
- No additional libraries or packages are required. The program uses only Python's standard library.

How to Check Your Python Installation
-------------------------------------
1. Open a command prompt (Windows) or terminal (Mac/Linux).
2. Type `python --version` or `python3 --version` and press Enter.
3. If you see a version number (e.g., "Python 3.8.5"), you are ready to proceed.
4. If you get an error, you will need to install Python from https://python.org

How to Run the Program
----------------------
1. **Save the File**
   Ensure the `atm.py` file is saved in a known directory on your computer.

2. **Open a Terminal/Command Prompt**
   - On Windows: Press `Win + R`, type `cmd`, and press Enter.
   - On Mac: Press `Cmd + Space`, type `Terminal`, and press Enter.
   - On Linux: Press `Ctrl + Alt + T`.

3. **Navigate to the Program Directory**
   Use the `cd` command to change to the directory where you saved `atm.py`.
   Examples:
     Windows: `cd C:\Users\YourName\Documents\atm_project`
     Mac/Linux: `cd /home/yourname/projects/atm_system`

4. **Execute the Program**
   Type the following command and press Enter:

or if that doesn't work, try:


How to Use the ATM System
-------------------------
Once the program is running, follow the on-screen prompts:

1. **Startup**: The program will display "=== ATM System Started ===".

2. **Insert Card**: When prompted, enter one of the valid test card numbers:
- Card: 1234567890 | PIN: 1234 | Balance: $1500.00 | Cash Available: $300.00
- Card: 0987654321 | PIN: 4321 | Balance: $500.00  | Cash Available: $100.00

3. **Enter PIN**: Type the 4-digit PIN corresponding to the card you entered.

4. **Select Operations**: After successful login, choose from the menu:
- Option 1: Cash Withdrawal
     * Important: Enter amount as a number only (e.g., `100` or `50.00`)
     * Do NOT use a dollar sign (`$`) or other characters.
- Option 2: Print Balance
- Option 3: Order Statement
- Option 4: Order Checkbook
- Option 5: Finish and eject your card

5. **Exit the System**:
- To end your session: Select Option 5 from the menu.
- To quit the entire program: Type `quit` when asked for a card number.
- Emergency exit: Press `Ctrl + C` in the terminal at any time.

Troubleshooting Common Issues
-----------------------------
- "Invalid amount": You entered non-numeric characters. Use only numbers and a decimal point (e.g., 100.50).
- "python: command not found": Try `python3` instead of `python`.
- "File not found": Make sure you are in the correct directory where the `atm.py` file is saved.
- "Invalid card number": Use one of the test card numbers provided above.

Implementation Details
----------------------
This code demonstrates three programming paradigms:

1. **Object-Oriented Programming (OOP)**
- Uses classes for BankAccount, Transaction, CashWithdrawal, etc.
- Implements encapsulation, inheritance, and polymorphism.
- Example: All transaction types inherit from a base Transaction class.

2. **Procedural Programming**
- The main script follows a sequential, step-by-step workflow.
- Uses simple data structures (dictionary) for the bank database.
- Example: The main() function controls the entire program flow.

3. **Functional Programming**
- Uses higher-order functions that take other functions as arguments.
- Implements pure functions for validation (no side effects).
- Example: The validate_input() function uses validator functions.

Important Notes
---------------
- This is a simulation. All data is stored in memory and is lost when the program closes.
- The system is for educational purposes to demonstrate programming concepts.
- No real financial transactions or personal data are involved.

Support
-------
If you encounter any issues running this program, please ensure:
1. Python is correctly installed
2. You are in the right directory in your terminal
3. You are using the provided test card numbers and PINs

Enjoy exploring the multi-paradigm ATM simulator!