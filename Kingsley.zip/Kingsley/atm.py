"""
A Multi-Paradigm Implementation of a Simplified ATM System.
This code demonstrates Object-Oriented, Procedural, and Functional programming styles.
"""

# --- OBJECT-ORIENTED PARADIGM ---
# The core business logic is modeled using classes and encapsulation.

class BankAccount:
    """
    Represents a customer's bank account.
    This class encapsulates the data and behaviors related to the account.
    """
    
    def __init__(self, account_number, pin, balance, available_cash):
        # Initialize the account's attributes.
        self.account_number = account_number
        self._pin = pin  # The underscore denotes a "protected" attribute, not to be accessed directly.
        self.balance = balance
        self.available_cash = available_cash

    def validate_pin(self, input_pin):
        """Checks if the provided PIN matches the account's PIN."""
        return self._pin == input_pin

    def withdraw(self, amount):
        """
        Withdraws a specified amount if funds are available.
        Returns True if successful, False otherwise.
        """
        if 0 < amount <= self.available_cash:
            self.available_cash -= amount
            self.balance -= amount  # Assuming balance also decreases
            return True
        return False

    def get_balance(self):
        """Returns the current account balance."""
        return self.balance


class Transaction:
    """
    An abstract base class for all types of transactions.
    This uses the "Command" pattern, allowing the ATM to execute any transaction uniformly.
    """
    
    def execute(self, account):
        """This method must be implemented by all subclasses."""
        raise NotImplementedError("Subclasses must implement the execute method.")


class CashWithdrawal(Transaction):
    """A concrete transaction for withdrawing cash."""
    
    def __init__(self, amount):
        # The amount to withdraw is set when the transaction object is created.
        self.amount = amount

    def execute(self, account):
        """Executes the cash withdrawal on the provided account."""
        if account.withdraw(self.amount):
            print(f"Dispensing ${self.amount}. Please take your cash.")
        else:
            print("Insufficient funds or invalid amount.")


class BalanceInquiry(Transaction):
    """A concrete transaction for checking the account balance."""
    
    def execute(self, account):
        """Executes the balance inquiry and displays the result."""
        balance = account.get_balance()
        print(f"Your current balance is: ${balance}")


class StatementOrder(Transaction):
    """A concrete transaction for ordering a statement."""
    
    def execute(self, account):
        """Executes the statement order process."""
        print(f"A statement for account {account.account_number} has been ordered and will be mailed to you.")


class CheckbookOrder(Transaction):
    """A concrete transaction for ordering a checkbook."""
    
    def execute(self, account):
        """Executes the checkbook order process."""
        print(f"A new checkbook for account {account.account_number} has been ordered.")


# --- PROCEDURAL PARADIGM ---
# This section uses a simple, step-by-step script to simulate the bank's database.
# It relies on basic data structures and sequential operations.

# Simulate a simple in-memory database using a dictionary.
# This is a procedural way to handle data storage.
bank_database = {
    "1234567890": BankAccount("1234567890", "1234", 1500.00, 300.00),
    "0987654321": BankAccount("0987654321", "4321", 500.00, 100.00)
}

def get_account_details(card_number):
    """
    A procedural function to look up an account by card number.
    Returns a BankAccount object if found, otherwise returns None.
    """
    return bank_database.get(card_number)

def update_account_information(account):
    """
    A procedural function to 'update' the account in the database.
    In this in-memory setup, the object is already updated, so we just print a log.
    """
    print(f"Account {account.account_number} updated in the bank's records.")


# --- FUNCTIONAL PARADIGM ---
# This section uses principles from functional programming, such as
# first-class functions, lambda expressions, and the filter function.

def get_transaction_type(option_number):
    """
    Returns a transaction object based on the user's menu selection.
    This uses a dictionary as a simple dispatch table, treating functions/objects as first-class citizens.
    """
    # A dictionary where keys are options and values are lambda functions that return Transaction objects.
    # This is a functional alternative to a long if/else or switch statement.
    transaction_options = {
        1: lambda amount: CashWithdrawal(amount),
        2: lambda _: BalanceInquiry(),  # The amount is ignored for balance inquiry.
        3: lambda _: StatementOrder(),
        4: lambda _: CheckbookOrder()
    }
    
    # Get the lambda function for the chosen option. If not found, return None.
    transaction_creator = transaction_options.get(option_number)
    
    if transaction_creator:
        return transaction_creator
    else:
        return None

def validate_input(input_string, validator_function):
    """
    A higher-order function that validates input using a provided validator function.
    This separates the validation logic from the act of getting input.
    """
    return validator_function(input_string)

# These are pure functions used for validation. They have no side effects.
# Their output depends only on their input.
def is_valid_card_number(card_number):
    """Validates the card number format."""
    return card_number.isdigit() and 10 <= len(card_number) <= 16

def is_valid_pin(pin):
    """Validates the PIN format."""
    return pin.isdigit() and len(pin) == 4

def is_valid_amount(amount_str):
    """Validates the withdrawal amount format."""
    try:
        amount = float(amount_str)
        return amount > 0
    except ValueError:
        return False


# --- MAIN PROGRAM (Procedural Script) ---
# This is the main entry point of the application, written in a procedural style.
# It defines the sequence of steps the ATM follows.

def main():
    """The main procedure that runs the ATM system loop."""
    
    print("=== ATM System Started ===")
    
    # This is the main loop from the pseudocode.
    while True:
        # Step 1: Get Card Input
        print("\nWelcome! Please enter your card number (or 'quit' to exit): ")
        card_input = input().strip()
        
        if card_input.lower() == 'quit':
            print("System shutting down. Goodbye.")
            break
        
        # Use the functional validator to check the card.
        if not validate_input(card_input, is_valid_card_number):
            print("Invalid card number format. Please try again.")
            continue
        
        # Procedural lookup of the account.
        user_account = get_account_details(card_input)
        
        if user_account is None:
            print("Card not recognized. Please contact your bank.")
            continue
        
        # Step 2: Authenticate with PIN
        print("Please enter your 4-digit PIN: ")
        pin_input = input().strip()
        
        # Use the functional validator to check the PIN.
        if not validate_input(pin_input, is_valid_pin):
            print("Invalid PIN format. It must be 4 digits.")
            continue
        
        # Object-Oriented: The BankAccount object validates the PIN.
        if not user_account.validate_pin(pin_input):
            print("Invalid PIN. Card retained. Please contact your bank.")
            # Object-Oriented: We could call an ATM.retain_card() method here.
            continue
        
        print("Authentication successful!")
        
        # Step 3: Transaction Loop
        while True:
            print("\nPlease select an operation:")
            print("1. Cash Withdrawal")
            print("2. Print Balance")
            print("3. Order Statement")
            print("4. Order Checkbook")
            print("5. Finish / Eject Card")
            
            try:
                option = int(input("Enter your choice (1-5): "))
            except ValueError:
                print("Invalid input. Please enter a number.")
                continue
            
            if option == 5:
                # User is done, break out of the transaction loop.
                break
            
            # FUNCTIONAL PARADIGM: Using the functional dispatcher.
            transaction_creator = get_transaction_type(option)
            
            if transaction_creator:
                # If the transaction requires an amount (like withdrawal), get it.
                if option == 1:
                    print("Enter amount to withdraw: ")
                    amount_input = input().strip()
                    if not validate_input(amount_input, is_valid_amount):
                        print("Invalid amount.")
                        continue
                    amount = float(amount_input)
                    transaction = transaction_creator(amount)
                else:
                    transaction = transaction_creator(None)  # Amount not needed.
                
                # OBJECT-ORIENTED PARADIGM: Polymorphism in action.
                # The same 'execute' method is called, but the behavior depends on the transaction type.
                transaction.execute(user_account)
                
                # PROCEDURAL PARADIGM: Update the database after a transaction.
                update_account_information(user_account)
                
            else:
                print("Invalid option selected.")
        
        # Step 4: End of Session
        print("Please take your card. Thank you for banking with us.")
        # The session ends, and the main loop restarts.

# This is a common Python idiom. It means "run the main() function if this script is executed directly".
if __name__ == "__main__":
    main()